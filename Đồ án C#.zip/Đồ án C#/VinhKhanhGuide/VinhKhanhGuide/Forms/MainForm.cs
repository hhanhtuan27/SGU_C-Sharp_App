using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
using GMap.NET;
using GMap.NET.MapProviders;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;
using VinhKhanhGuide.Controls;
using VinhKhanhGuide.Models;
using VinhKhanhGuide.Services;

namespace VinhKhanhGuide.Forms
{
    public partial class MainForm : Form
    {
        // ============================================================
        // Services (khởi tạo trong OnLoad để Designer không crash)
        // ============================================================
        private PoiRepository _repo;
        private GeofenceService _geofence;
        private NarrationService _narration;
        private GpsSimulator _simulator;
        private List<PointOfInterest> _pois;

        // ============================================================
        // Theme — phong cách dark mode "phố ẩm thực đêm"
        // ============================================================
        private static readonly Color ColBg = Color.FromArgb(22, 24, 28);
        private static readonly Color ColPanel = Color.FromArgb(30, 32, 38);
        private static readonly Color ColPanelAlt = Color.FromArgb(37, 40, 47);
        private static readonly Color ColBorder = Color.FromArgb(55, 60, 70);
        private static readonly Color ColAccent = Color.FromArgb(255, 140, 66);  // neon orange
        private static readonly Color ColText = Color.FromArgb(235, 237, 240);
        private static readonly Color ColTextMuted = Color.FromArgb(160, 165, 175);

        // ============================================================
        // Map layers
        // ============================================================
        private GMapControl _map;
        private GMapOverlay _poiOverlay;
        private GMapOverlay _userOverlay;
        private GMapOverlay _radiusOverlay;
        private GMapMarker _userMarker;

        // ============================================================
        // Left pane controls
        // ============================================================
        private PoiListBox _poiList;
        private TextBox _searchBox;
        private Label _lblStatus;
        private ComboBox _cboLang;

        // ============================================================
        // Status strip
        // ============================================================
        private Label _lblZoom;
        private Action<double, double> _updateCoords;
        private Action<string> _updateSelection;

        // ============================================================
        // State
        // ============================================================
        private NarrationLanguage _language = NarrationLanguage.VN;
        private PoiCategory? _activeCategory = null;

        public MainForm()
        {
            // Designer chỉ chạy InitializeComponent, không chạm services.
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            // Chặn không cho code dưới chạy khi VS đang render Designer.
            if (DesignMode || LicenseManager.UsageMode == LicenseUsageMode.Designtime) return;

            // Connection string đọc từ App.config; có default phòng khi thiếu.
            var connStr = System.Configuration.ConfigurationManager
                             .ConnectionStrings["VinhKhanhDb"]?.ConnectionString
                         ?? @"Server=(local);Database=VinhKhanhGuide;Integrated Security=True;";

            _repo = new PoiRepository(connStr);
            _pois = _repo.LoadAll();          // Tự fallback seed nếu DB chết
            _geofence = new GeofenceService(_pois);
            _narration = new NarrationService();   // WinRT TTS — đọc trực tiếp DB
            _simulator = new GpsSimulator();

            WireEvents();
            LoadMap();
            PopulatePoiList();
            UpdateStatus("Sẵn sàng. Click 1 quán để nghe thuyết minh.");
        }

        // ============================================================
        // INITIALIZE COMPONENT — layout chính của form
        // ============================================================
        private void InitializeComponent()
        {
            SuspendLayout();
            Text = "POI Navigator — Vĩnh Khánh, Ho Chi Minh City";
            Size = new Size(1360, 780);
            MinimumSize = new Size(1024, 640);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = ColBg;
            ForeColor = ColText;
            Font = new Font("Segoe UI", 9f);

            // Split container: trái 30% (sidebar), phải 70% (map)
            var split = new SplitContainer
            {
                Dock = DockStyle.Fill,
                SplitterWidth = 1,
                BackColor = ColBorder,
                FixedPanel = FixedPanel.Panel1,
                IsSplitterFixed = false,
                Panel1MinSize = 300
            };
            split.Panel1.BackColor = ColPanel;
            split.Panel2.BackColor = ColBg;

            BuildLeftPane(split.Panel1);
            BuildRightPane(split.Panel2);

            Controls.Add(split);

            // Set tỷ lệ 30/70 SAU khi form được show (lúc này ClientSize đã ổn).
            Shown += (s, e) =>
            {
                try { split.SplitterDistance = Math.Max(320, (int)(ClientSize.Width * 0.30)); }
                catch { /* nuốt nếu ClientSize quá nhỏ */ }
            };

            Controls.Add(BuildStatusStrip());
            Controls.Add(BuildMenuStrip());
            MainMenuStrip = (MenuStrip)Controls[Controls.Count - 1];

            ResumeLayout(false);
            PerformLayout();
        }

        private MenuStrip BuildMenuStrip()
        {
            var menu = new MenuStrip
            {
                BackColor = ColPanel,
                ForeColor = ColText,
                Renderer = new DarkMenuRenderer()
            };
            foreach (var label in new[] { "File", "View", "Map", "Tools", "Help" })
            {
                var item = new ToolStripMenuItem(label) { ForeColor = ColText };

                if (label == "Map")
                {
                    var refreshItem = new ToolStripMenuItem("🔄 Refresh POIs from DB")
                    {
                        ForeColor = ColText,
                        ShortcutKeys = Keys.F5
                    };
                    refreshItem.Click += (s, e) => RefreshPoisFromDatabase();
                    item.DropDownItems.Add(refreshItem);
                }

                menu.Items.Add(item);
            }
            return menu;
        }

        /// <summary>
        /// Reload POIs từ DB. Gọi khi web vừa thêm/sửa quán → app cập nhật ngay
        /// mà không cần restart.
        /// </summary>
        private void RefreshPoisFromDatabase()
        {
            try
            {
                _pois = _repo.LoadAll();

                // Refresh geofence engine với danh sách mới
                _geofence = new GeofenceService(_pois);
                _geofence.GeofenceEntered += Geofence_Entered;

                // Reload markers trên map
                _poiOverlay.Markers.Clear();
                foreach (var poi in _pois)
                {
                    var color = poi.Category == PoiCategory.CaPhe
                        ? GMarkerGoogleType.blue_small
                        : GMarkerGoogleType.red_small;
                    var m = new GMarkerGoogle(new PointLatLng(poi.Latitude, poi.Longitude), color)
                    {
                        ToolTipText = poi.Name,
                        ToolTipMode = MarkerTooltipMode.OnMouseOver,
                        Tag = poi
                    };
                    _poiOverlay.Markers.Add(m);
                }

                // Reload list bên trái (giữ filter hiện tại)
                ApplyFilter();
                _map.Refresh();

                UpdateStatus($"Đã refresh: {_pois.Count} quán");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi refresh POIs: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ============================================================
        // LEFT PANE — sidebar
        // ============================================================
        private void BuildLeftPane(Control host)
        {
            // ----- Header -----
            var header = new Panel
            {
                Dock = DockStyle.Top,
                Height = 42,
                BackColor = Color.FromArgb(58, 50, 90)
            };
            header.Paint += (s, e) =>
            {
                using (var f = new Font("Segoe UI Semibold", 10.5f, FontStyle.Bold))
                using (var b = new SolidBrush(ColText))
                    e.Graphics.DrawString("📍  Points of Interest", f, b, 14, 11);
            };

            // ----- Search box -----
            var searchPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 44,
                BackColor = ColPanel,
                Padding = new Padding(12, 8, 12, 8)
            };
            _searchBox = new TextBox
            {
                Dock = DockStyle.Fill,
                BackColor = ColPanelAlt,
                ForeColor = ColText,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Segoe UI", 9.5f)
            };
            _searchBox.Text = "Search POIs...";
            _searchBox.GotFocus += (s, e) => { if (_searchBox.Text == "Search POIs...") _searchBox.Text = ""; };
            _searchBox.LostFocus += (s, e) => { if (string.IsNullOrWhiteSpace(_searchBox.Text)) _searchBox.Text = "Search POIs..."; };
            _searchBox.TextChanged += (s, e) => ApplyFilter();
            searchPanel.Controls.Add(_searchBox);

            // ----- Filter chips theo category -----
            var filterPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                Height = 38,
                BackColor = ColPanel,
                Padding = new Padding(10, 4, 10, 4),
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false
            };

            Button activeBtn = null;
            Button MakeChip(string label, PoiCategory? cat, Color accent)
            {
                var b = new Button
                {
                    Text = label,
                    AutoSize = true,
                    Height = 26,
                    ForeColor = ColText,
                    BackColor = ColPanelAlt,
                    FlatStyle = FlatStyle.Flat,
                    Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold),
                    Margin = new Padding(0, 2, 6, 2),
                    Padding = new Padding(8, 0, 8, 0),
                    Tag = cat
                };
                b.FlatAppearance.BorderColor = accent;
                b.FlatAppearance.BorderSize = 1;
                b.Click += (s, e) =>
                {
                    if (activeBtn != null) activeBtn.BackColor = ColPanelAlt;
                    activeBtn = b;
                    b.BackColor = Color.FromArgb(60, accent);
                    ApplyFilterWithCategory((PoiCategory?)b.Tag);
                };
                return b;
            }

            filterPanel.Controls.Add(MakeChip("All", null, ColAccent));
            filterPanel.Controls.Add(MakeChip("Ốc", PoiCategory.Oc, PoiCategory.Oc.AccentColor()));
            filterPanel.Controls.Add(MakeChip("Nướng", PoiCategory.Nuong, PoiCategory.Nuong.AccentColor()));
            filterPanel.Controls.Add(MakeChip("Lẩu", PoiCategory.Lau, PoiCategory.Lau.AccentColor()));
            filterPanel.Controls.Add(MakeChip("Cà phê", PoiCategory.CaPhe, PoiCategory.CaPhe.AccentColor()));
            filterPanel.Controls.Add(MakeChip("Món khác", PoiCategory.Khac, PoiCategory.Khac.AccentColor()));  // ← thêm

            // ----- Status bar nhỏ ở dưới cùng -----
            _lblStatus = new Label
            {
                Dock = DockStyle.Bottom,
                Height = 26,
                Text = "  Sẵn sàng",
                ForeColor = ColTextMuted,
                BackColor = ColPanelAlt,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(8, 0, 0, 0),
                Font = new Font("Segoe UI", 8.5f)
            };

            // ----- ComboBox ngôn ngữ với cờ + tên đầy đủ -----
            var langPanel = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 40,
                BackColor = ColPanel,
                Padding = new Padding(10, 5, 10, 5)
            };
            _cboLang = new ComboBox
            {
                Dock = DockStyle.Fill,
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = ColPanelAlt,
                ForeColor = ColText,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI Semibold", 10f, FontStyle.Bold)
            };
            foreach (NarrationLanguage l in Enum.GetValues(typeof(NarrationLanguage)))
                _cboLang.Items.Add(l);
            _cboLang.SelectedIndex = 0;

            // Hiển thị "🇻🇳   Tiếng Việt" thay vì "VN"
            _cboLang.Format += (s, e) =>
            {
                var lang = (NarrationLanguage)e.ListItem;
                string flag;
                switch (lang)
                {
                    case NarrationLanguage.VN: flag = "🇻🇳"; break;
                    case NarrationLanguage.EN: flag = "🇬🇧"; break;
                    case NarrationLanguage.JP: flag = "🇯🇵"; break;
                    case NarrationLanguage.KR: flag = "🇰🇷"; break;
                    case NarrationLanguage.CN: flag = "🇨🇳"; break;
                    default: flag = "🌐"; break;
                }
                e.Value = $"  {flag}   {lang.DisplayName()}";
            };
            _cboLang.SelectedIndexChanged += (s, e) =>
            {
                _language = (NarrationLanguage)_cboLang.SelectedItem;
                _narration?.SetLanguage(_language);
                _poiList.Language = _language == NarrationLanguage.VN ? "VN" : "EN";
                _poiList.Invalidate();
            };
            langPanel.Controls.Add(_cboLang);

            // ----- POI list -----
            _poiList = new PoiListBox { Dock = DockStyle.Fill };
            _poiList.SelectedIndexChanged += PoiList_SelectedIndexChanged;

            // THỨ TỰ Add quan trọng: Dock stack ngược theo Z-order.
            // Add sau nằm TRÊN add trước với cùng Dock.
            host.Controls.Add(_poiList);     // Fill (chiếm phần giữa)
            host.Controls.Add(_lblStatus);   // Bottom dưới cùng
            host.Controls.Add(langPanel);    // Bottom trên status
            host.Controls.Add(filterPanel);  // Top dưới search
            host.Controls.Add(searchPanel);  // Top dưới header
            host.Controls.Add(header);       // Top trên cùng
        }

        // ============================================================
        // RIGHT PANE — toolbar + map
        // ============================================================
        private void BuildRightPane(Control host)
        {
            var toolbar = new Panel
            {
                Dock = DockStyle.Top,
                Height = 42,
                BackColor = ColPanel
            };
            toolbar.Paint += (s, e) =>
            {
                using (var pen = new Pen(ColBorder))
                    e.Graphics.DrawLine(pen, 0, toolbar.Height - 1, toolbar.Width, toolbar.Height - 1);
            };

            int x = 8;
            foreach (var (label, handler) in new (string, EventHandler)[]
            {
                ("🔍  Zoom In",  (s, e) => { if (_map != null) _map.Zoom += 1; UpdateZoomLabel(); }),
                ("🔎  Zoom Out", (s, e) => { if (_map != null) _map.Zoom -= 1; UpdateZoomLabel(); }),
                ("◎  Centre",    (s, e) => CenterOnPois()),
            })
            {
                var b = MakeToolbarButton(label);
                b.Location = new Point(x, 6);
                b.Click += handler;
                toolbar.Controls.Add(b);
                x += b.Width + 6;
            }
            _lblZoom = new Label
            {
                Text = "Zoom: 16",
                ForeColor = ColText,
                Location = new Point(x + 4, 13),
                AutoSize = true
            };
            toolbar.Controls.Add(_lblZoom);

            _map = new GMapControl
            {
                Dock = DockStyle.Fill,
                MapProvider = GMapProviders.GoogleMap, // Google ổn định hơn OSM
                MinZoom = 2,
                MaxZoom = 20,
                Zoom = 16,
                DragButton = MouseButtons.Left,
                ShowCenter = false,
                Position = new PointLatLng(10.7607, 106.7035),
                BackColor = ColBg
            };
            _map.OnMapZoomChanged += () => UpdateZoomLabel();

            host.Controls.Add(_map);
            host.Controls.Add(toolbar);
        }

        private StatusStrip BuildStatusStrip()
        {
            var strip = new StatusStrip
            {
                BackColor = ColPanel,
                SizingGrip = false,
                Renderer = new DarkMenuRenderer()
            };
            strip.Items.Add(new ToolStripStatusLabel("Status: Ready") { ForeColor = ColText });
            strip.Items.Add(new ToolStripStatusLabel() { Spring = true });
            var lblCoords = new ToolStripStatusLabel("Lat: 10.7607°  Lon: 106.7035°") { ForeColor = ColTextMuted };
            var lblSel = new ToolStripStatusLabel("No selection") { ForeColor = ColTextMuted };
            strip.Items.Add(lblCoords);
            strip.Items.Add(new ToolStripSeparator());
            strip.Items.Add(lblSel);

            _updateCoords = (lat, lon) => lblCoords.Text = $"Lat: {lat:F4}°  Lon: {lon:F4}°";
            _updateSelection = text => lblSel.Text = text;
            return strip;
        }

        private Button MakeToolbarButton(string text)
        {
            var b = new Button
            {
                Text = text,
                ForeColor = ColText,
                BackColor = ColPanelAlt,
                FlatStyle = FlatStyle.Flat,
                AutoSize = true,
                Padding = new Padding(8, 2, 8, 2)
            };
            b.FlatAppearance.BorderColor = ColBorder;
            b.FlatAppearance.BorderSize = 1;
            return b;
        }

        // ============================================================
        // SERVICES WIRING
        // ============================================================
        private void WireEvents()
        {
            _geofence.GeofenceEntered += Geofence_Entered;
            _narration.SpeakingStarted += (s, text) => BeginInvoke((Action)(() =>
            {
                _lblStatus.Text = "  🔊 " + (text ?? "");
            }));
            _narration.SpeakingCompleted += (s, e) => BeginInvoke((Action)(() =>
            {
                _lblStatus.Text = "  Sẵn sàng";
                _poiList.NowPlayingPoiId = -1;
                _poiList.Invalidate();
            }));
            _simulator.LocationChanged += Simulator_LocationChanged;

            _narration.SetLanguage(_language);
        }

        private void LoadMap()
        {
            // FIX 418: OSM/Google đều cần UserAgent rõ ràng.
            // Dòng này PHẢI chạy trước khi GMapControl fetch tile đầu tiên.
            GMapProvider.UserAgent = "VinhKhanhGuide/1.0 (student-project)";
            GMaps.Instance.Mode = AccessMode.ServerAndCache;

            _poiOverlay = new GMapOverlay("pois");
            _userOverlay = new GMapOverlay("user");
            _radiusOverlay = new GMapOverlay("radius");
            _map.Overlays.Add(_radiusOverlay);
            _map.Overlays.Add(_poiOverlay);
            _map.Overlays.Add(_userOverlay);

            foreach (var poi in _pois)
            {
                var color = poi.Category == PoiCategory.CaPhe
                    ? GMarkerGoogleType.blue_small
                    : GMarkerGoogleType.red_small;
                var m = new GMarkerGoogle(new PointLatLng(poi.Latitude, poi.Longitude), color)
                {
                    ToolTipText = poi.Name,
                    ToolTipMode = MarkerTooltipMode.OnMouseOver,
                    Tag = poi
                };
                _poiOverlay.Markers.Add(m);
            }

            // Click marker trên map → tự động thuyết minh quán đó.
            _map.OnMarkerClick += (marker, mouseEvt) =>
            {
                if (marker.Tag is PointOfInterest poi)
                {
                    _map.Position = marker.Position;
                    _map.Zoom = 18;
                    UpdateZoomLabel();
                    _updateSelection?.Invoke(poi.Name);
                    NarrateNow(poi);
                }
            };

            _userMarker = new GMarkerGoogle(
                new PointLatLng(10.760719, 106.703297),
                GMarkerGoogleType.green);
            _userMarker.ToolTipText = "You";
            _userOverlay.Markers.Add(_userMarker);

            CenterOnPois();
            UpdateZoomLabel();
        }

        private void PopulatePoiList()
        {
            _poiList.Language = _language == NarrationLanguage.VN ? "VN" : "EN";
            _poiList.SetSource(_pois);
        }

        private void ApplyFilterWithCategory(PoiCategory? cat)
        {
            _activeCategory = cat;
            ApplyFilter();
        }

        private void ApplyFilter()
        {
            var q = _searchBox.Text?.Trim();
            IEnumerable<PointOfInterest> src = _pois;

            if (_activeCategory.HasValue)
                src = src.Where(p => p.Category == _activeCategory.Value);

            if (!string.IsNullOrEmpty(q) && q != "Search POIs...")
                src = src.Where(p => p.Name.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0);

            _poiList.SetSource(src.OrderBy(p => p.Category).ThenByDescending(p => p.Priority));
            FilterMapMarkers(_activeCategory);
        }

        /// <summary>Ẩn/hiện marker trên bản đồ theo category đã chọn.</summary>
        private void FilterMapMarkers(PoiCategory? category)
        {
            if (_poiOverlay == null) return;
            foreach (var marker in _poiOverlay.Markers)
            {
                var poi = marker.Tag as PointOfInterest;
                if (poi == null) { marker.IsVisible = true; continue; }
                marker.IsVisible = !category.HasValue || poi.Category == category.Value;
            }
            _map.Refresh();
        }

        // ============================================================
        // EVENT HANDLERS
        // ============================================================

        /// <summary>
        /// Click POI trong danh sách → pan map + zoom + tự động thuyết minh.
        /// Đây là cách user trigger narration chính trong app.
        /// </summary>
        private void PoiList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_poiList.SelectedItem is PointOfInterest poi)
            {
                _map.Position = new PointLatLng(poi.Latitude, poi.Longitude);
                _map.Zoom = 18;
                UpdateZoomLabel();
                _updateSelection?.Invoke(poi.Name);
                NarrateNow(poi);
            }
        }

        /// <summary>Trigger thuyết minh ngay lập tức + highlight quán trong list.</summary>
        private void NarrateNow(PointOfInterest poi)
        {
            _poiList.NowPlayingPoiId = poi.Id;
            _poiList.Invalidate();
            _narration.Speak(poi);
        }

        private void Simulator_LocationChanged(object sender, LocationChangedEventArgs e)
        {
            BeginInvoke((Action)(() =>
            {
                _userMarker.Position = new PointLatLng(e.Latitude, e.Longitude);
                _map.Position = _userMarker.Position;
                _updateCoords?.Invoke(e.Latitude, e.Longitude);
                _geofence.UpdateLocation(e.Latitude, e.Longitude);
            }));
        }

        private void Geofence_Entered(object sender, GeofenceEnteredEventArgs e)
        {
            BeginInvoke((Action)(() =>
            {
                _updateSelection?.Invoke($"▶ {e.Poi.Name} ({e.DistanceMeters:F1} m)");
                NarrateNow(e.Poi);
            }));
        }

        // ============================================================
        // HELPERS
        // ============================================================
        private void CenterOnPois()
        {
            if (_pois == null || _pois.Count == 0) return;
            var pts = _pois.Select(p => new PointLatLng(p.Latitude, p.Longitude)).ToList();
            var rect = RectLatLngFromPoints(pts);
            _map.SetZoomToFitRect(rect);
            UpdateZoomLabel();
        }

        private static RectLatLng RectLatLngFromPoints(List<PointLatLng> pts)
        {
            double minLat = pts.Min(p => p.Lat), maxLat = pts.Max(p => p.Lat);
            double minLng = pts.Min(p => p.Lng), maxLng = pts.Max(p => p.Lng);
            return RectLatLng.FromLTRB(minLng, maxLat, maxLng, minLat);
        }

        private void UpdateZoomLabel()
        {
            if (_map != null && _lblZoom != null)
                _lblZoom.Text = $"Zoom: {(int)_map.Zoom}";
        }

        private void UpdateStatus(string text)
        {
            if (_lblStatus != null) _lblStatus.Text = "  " + text;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _simulator?.StopRoute();
            _narration?.Dispose();
            base.OnFormClosing(e);
        }

        // ============================================================
        // DARK THEME RENDERER cho MenuStrip/StatusStrip
        // ============================================================
        private class DarkMenuRenderer : ToolStripProfessionalRenderer
        {
            public DarkMenuRenderer() : base(new DarkColors()) { }
        }
        private class DarkColors : ProfessionalColorTable
        {
            public override Color MenuItemSelected => ColPanelAlt;
            public override Color MenuItemSelectedGradientBegin => ColPanelAlt;
            public override Color MenuItemSelectedGradientEnd => ColPanelAlt;
            public override Color ToolStripDropDownBackground => ColPanel;
            public override Color ImageMarginGradientBegin => ColPanel;
            public override Color ImageMarginGradientMiddle => ColPanel;
            public override Color ImageMarginGradientEnd => ColPanel;
            public override Color MenuBorder => ColBorder;
            public override Color MenuItemBorder => ColAccent;
            public override Color ToolStripBorder => ColBorder;
            public override Color StatusStripGradientBegin => ColPanel;
            public override Color StatusStripGradientEnd => ColPanel;
        }
    }
}