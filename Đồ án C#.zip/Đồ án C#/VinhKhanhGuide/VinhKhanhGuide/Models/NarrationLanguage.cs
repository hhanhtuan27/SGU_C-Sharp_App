﻿using System.Globalization;

namespace VinhKhanhGuide.Models
{
    public enum NarrationLanguage { VN, EN, JP, KR, CN }

    public static class NarrationLanguageExtensions
    {
        public static CultureInfo ToCulture(this NarrationLanguage lang)
        {
            switch (lang)
            {
                case NarrationLanguage.VN: return new CultureInfo("vi-VN");
                case NarrationLanguage.EN: return new CultureInfo("en-US");
                case NarrationLanguage.JP: return new CultureInfo("ja-JP");
                case NarrationLanguage.KR: return new CultureInfo("ko-KR");
                case NarrationLanguage.CN: return new CultureInfo("zh-CN");
                default: return new CultureInfo("en-US");
            }
        }

        public static string DisplayName(this NarrationLanguage l)
        {
            switch (l)
            {
                case NarrationLanguage.VN: return "Tiếng Việt";
                case NarrationLanguage.EN: return "English";
                case NarrationLanguage.JP: return "日本語";
                case NarrationLanguage.KR: return "한국어";
                case NarrationLanguage.CN: return "中文";
                default: return l.ToString();
            }
        }
    }
}