using System.Drawing;

namespace VinhKhanhGuide.Models
{
    /// <summary>
    /// Loại điểm ẩm thực. Khi web admin thêm POI mới, gán Category này
    /// theo string trong DB ("Oc", "Nuong", "Lau", "CaPhe", "Khac").
    /// "Khac" dùng cho các món không thuộc 4 loại chính (cơm, bún, chè...).
    /// </summary>
    public enum PoiCategory
    {
        Oc = 0,
        Nuong = 1,
        Lau = 2,
        CaPhe = 3,
        Khac = 4    // ← thêm mới
    }

    public static class PoiCategoryExtensions
    {
        public static PoiCategory Parse(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return PoiCategory.Khac;
            switch (raw.Trim().ToLowerInvariant())
            {
                case "oc": return PoiCategory.Oc;
                case "nuong": return PoiCategory.Nuong;
                case "lau": return PoiCategory.Lau;
                case "caphe": return PoiCategory.CaPhe;
                case "khac": return PoiCategory.Khac;
                default: return PoiCategory.Khac;  // fallback an toàn
            }
        }

        public static string DisplayName(this PoiCategory c, string language)
        {
            bool vn = string.Equals(language, "VN", System.StringComparison.OrdinalIgnoreCase);
            switch (c)
            {
                case PoiCategory.Oc: return vn ? "Ốc" : "Shellfish";
                case PoiCategory.Nuong: return vn ? "Nướng" : "Grill";
                case PoiCategory.Lau: return vn ? "Lẩu" : "Hot Pot";
                case PoiCategory.CaPhe: return vn ? "Cà phê" : "Cafe";
                case PoiCategory.Khac: return vn ? "Món khác" : "Other";
                default: return c.ToString();
            }
        }

        public static Color AccentColor(this PoiCategory c)
        {
            switch (c)
            {
                case PoiCategory.Oc: return Color.FromArgb(255, 140, 66); // warm orange
                case PoiCategory.Nuong: return Color.FromArgb(230, 57, 70); // grill red
                case PoiCategory.Lau: return Color.FromArgb(244, 162, 97); // amber
                case PoiCategory.CaPhe: return Color.FromArgb(111, 168, 220); // cafe blue
                case PoiCategory.Khac: return Color.FromArgb(160, 160, 160); // grey trung tính
                default: return Color.Gainsboro;
            }
        }
    }
}