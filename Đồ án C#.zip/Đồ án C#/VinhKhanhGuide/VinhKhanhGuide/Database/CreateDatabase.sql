/* =====================================================================
   VinhKhanhGuide — Database Schema v2 (Flat Multilingual)
   ---------------------------------------------------------------------
   Mục tiêu:
   - Backward-compatible 100% với app WinForms hiện tại
   - Hỗ trợ 5 ngôn ngữ mô tả (VN/EN/JP/KR/CN) dưới dạng cột phẳng
   - Category string + CHECK constraint (5 giá trị cố định khớp enum C#)
   - Web admin có đầy đủ field: địa chỉ, SĐT, giờ mở cửa, giá, ảnh, Google Maps link
   - Auto-update UpdatedAt qua trigger → App F5 refresh biết cái nào mới
   - Views thống kê sẵn cho dashboard web admin
   ---------------------------------------------------------------------
   Chạy: sqlcmd -S (local) -E -i CreateDatabase_v2.sql
         hoặc mở trong SSMS, chọn master DB, nhấn F5.
   ===================================================================== */

USE master;
GO

IF DB_ID('VinhKhanhGuide') IS NOT NULL
BEGIN
    ALTER DATABASE VinhKhanhGuide SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE VinhKhanhGuide;
END
GO

CREATE DATABASE VinhKhanhGuide COLLATE Vietnamese_CI_AS;
GO
USE VinhKhanhGuide;
GO

/* =====================================================================
   1. BẢNG CHÍNH: PointsOfInterest
   ===================================================================== */
CREATE TABLE dbo.PointsOfInterest (
    Id              INT IDENTITY(1,1)   NOT NULL,
    Name            NVARCHAR(150)       NOT NULL,
    Category        NVARCHAR(20)        NOT NULL,
    Latitude        FLOAT               NOT NULL,
    Longitude       FLOAT               NOT NULL,
    RadiusMeters    FLOAT               NOT NULL DEFAULT 30,
    Priority        INT                 NOT NULL DEFAULT 1,

    -- Mô tả đa ngôn ngữ (flat columns, khớp enum NarrationLanguage C#)
    DescriptionVi   NVARCHAR(1000)      NULL,
    DescriptionEn   NVARCHAR(1000)      NULL,
    DescriptionJp   NVARCHAR(1000)      NULL,
    DescriptionKr   NVARCHAR(1000)      NULL,
    DescriptionCn   NVARCHAR(1000)      NULL,

    -- Thông tin bổ sung cho web admin (đều NULL — không bắt buộc nhập)
    Address         NVARCHAR(300)       NULL,
    PhoneNumber     NVARCHAR(20)        NULL,
    OpeningHours    NVARCHAR(100)       NULL,
    PriceRange      NVARCHAR(50)        NULL,
    ImageUrl        NVARCHAR(500)       NULL,
    GoogleMapsLink  NVARCHAR(1000)      NULL,

    IsActive        BIT                 NOT NULL DEFAULT 1,
    CreatedAt       DATETIME2           NOT NULL DEFAULT SYSUTCDATETIME(),
    UpdatedAt       DATETIME2           NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_PointsOfInterest PRIMARY KEY CLUSTERED (Id),

    CONSTRAINT CK_POI_Category
        CHECK (Category IN (N'Oc', N'Nuong', N'Lau', N'CaPhe', N'Khac')),

    CONSTRAINT CK_POI_Latitude
        CHECK (Latitude BETWEEN -90 AND 90),

    CONSTRAINT CK_POI_Longitude
        CHECK (Longitude BETWEEN -180 AND 180),

    CONSTRAINT CK_POI_Radius
        CHECK (RadiusMeters > 0 AND RadiusMeters <= 1000),

    CONSTRAINT CK_POI_Priority
        CHECK (Priority BETWEEN 1 AND 10)
);
GO

/* =====================================================================
   2. BẢNG LOG: NarrationLog (giữ nguyên schema cũ + CHECK ngôn ngữ)
   ===================================================================== */
CREATE TABLE dbo.NarrationLog (
    Id          BIGINT IDENTITY(1,1) NOT NULL,
    PoiId       INT                  NOT NULL,
    Language    NVARCHAR(5)          NOT NULL,
    PlayedAt    DATETIME2            NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_NarrationLog PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT FK_NarrationLog_Poi
        FOREIGN KEY (PoiId) REFERENCES dbo.PointsOfInterest(Id)
        ON DELETE CASCADE,
    CONSTRAINT CK_NarrationLog_Language
        CHECK (Language IN (N'VN', N'EN', N'JP', N'KR', N'CN'))
);
GO

/* =====================================================================
   3. INDEXES — tối ưu các query app và web thường dùng
   ===================================================================== */

CREATE NONCLUSTERED INDEX IX_POI_Category_Active
    ON dbo.PointsOfInterest (Category, IsActive)
    INCLUDE (Name, Latitude, Longitude, RadiusMeters, Priority);
GO

CREATE NONCLUSTERED INDEX IX_POI_Location
    ON dbo.PointsOfInterest (Latitude, Longitude)
    WHERE IsActive = 1;
GO

CREATE NONCLUSTERED INDEX IX_POI_Priority
    ON dbo.PointsOfInterest (Priority DESC, Id)
    WHERE IsActive = 1;
GO

CREATE NONCLUSTERED INDEX IX_NarrationLog_PoiId_PlayedAt
    ON dbo.NarrationLog (PoiId, PlayedAt DESC);
GO

CREATE NONCLUSTERED INDEX IX_NarrationLog_PlayedAt
    ON dbo.NarrationLog (PlayedAt DESC)
    INCLUDE (PoiId, Language);
GO

/* =====================================================================
   4. TRIGGER — auto update UpdatedAt khi có UPDATE
   ===================================================================== */
CREATE TRIGGER trg_POI_UpdatedAt
ON dbo.PointsOfInterest
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT UPDATE(UpdatedAt)   -- tránh loop vô hạn nếu ai set tay
    BEGIN
        UPDATE p
        SET UpdatedAt = SYSUTCDATETIME()
        FROM dbo.PointsOfInterest p
        INNER JOIN inserted i ON p.Id = i.Id;
    END
END
GO

/* =====================================================================
   5. VIEWS
   ===================================================================== */

/* 5.1 — vw_ActivePois: BACKWARD COMPAT cho app WinForms.
   Trả về đúng cấu trúc câu SELECT cũ trong PoiRepository.cs. */
CREATE VIEW dbo.vw_ActivePois
AS
SELECT
    Id, Name, Category,
    Latitude, Longitude, RadiusMeters, Priority,
    DescriptionVi, DescriptionEn,
    IsActive
FROM dbo.PointsOfInterest
WHERE IsActive = 1;
GO

/* 5.2 — vw_PoiFull: đầy đủ mọi field + flag HasXx cho web admin */
CREATE VIEW dbo.vw_PoiFull
AS
SELECT
    Id, Name, Category,
    Latitude, Longitude, RadiusMeters, Priority,
    DescriptionVi, DescriptionEn, DescriptionJp, DescriptionKr, DescriptionCn,
    Address, PhoneNumber, OpeningHours, PriceRange,
    ImageUrl, GoogleMapsLink,
    IsActive, CreatedAt, UpdatedAt,
    CASE WHEN DescriptionVi IS NOT NULL AND LEN(DescriptionVi) > 0 THEN 1 ELSE 0 END AS HasVi,
    CASE WHEN DescriptionEn IS NOT NULL AND LEN(DescriptionEn) > 0 THEN 1 ELSE 0 END AS HasEn,
    CASE WHEN DescriptionJp IS NOT NULL AND LEN(DescriptionJp) > 0 THEN 1 ELSE 0 END AS HasJp,
    CASE WHEN DescriptionKr IS NOT NULL AND LEN(DescriptionKr) > 0 THEN 1 ELSE 0 END AS HasKr,
    CASE WHEN DescriptionCn IS NOT NULL AND LEN(DescriptionCn) > 0 THEN 1 ELSE 0 END AS HasCn
FROM dbo.PointsOfInterest;
GO

/* 5.3 — vw_TopPois: Top quán nghe nhiều nhất */
CREATE VIEW dbo.vw_TopPois
AS
SELECT TOP 100
    p.Id,
    p.Name,
    p.Category,
    COUNT(n.Id)                AS TotalPlays,
    COUNT(DISTINCT n.Language) AS LanguagesUsed,
    MAX(n.PlayedAt)            AS LastPlayedAt
FROM dbo.PointsOfInterest p
LEFT JOIN dbo.NarrationLog n ON p.Id = n.PoiId
WHERE p.IsActive = 1
GROUP BY p.Id, p.Name, p.Category
ORDER BY TotalPlays DESC, p.Name;
GO

/* 5.4 — vw_NarrationByLanguage */
CREATE VIEW dbo.vw_NarrationByLanguage
AS
SELECT
    Language,
    COUNT(*)                AS TotalPlays,
    COUNT(DISTINCT PoiId)   AS UniquePois,
    MIN(PlayedAt)           AS FirstPlayedAt,
    MAX(PlayedAt)           AS LastPlayedAt
FROM dbo.NarrationLog
GROUP BY Language;
GO

/* 5.5 — vw_DailyHeatmap: 30 ngày gần nhất */
CREATE VIEW dbo.vw_DailyHeatmap
AS
SELECT
    p.Id            AS PoiId,
    p.Name          AS PoiName,
    p.Category,
    CAST(n.PlayedAt AS DATE) AS PlayDate,
    COUNT(*)        AS PlayCount
FROM dbo.NarrationLog n
INNER JOIN dbo.PointsOfInterest p ON n.PoiId = p.Id
WHERE n.PlayedAt >= DATEADD(DAY, -30, SYSUTCDATETIME())
GROUP BY p.Id, p.Name, p.Category, CAST(n.PlayedAt AS DATE);
GO

/* =====================================================================
   6. STORED PROCEDURES
   ===================================================================== */

/* 6.1 — sp_GetActivePois: danh sách POI kèm mô tả theo ngôn ngữ
   (có fallback EN -> VN nếu ngôn ngữ yêu cầu NULL) */
CREATE PROCEDURE dbo.sp_GetActivePois
    @Language NVARCHAR(5) = N'VN'
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        Id, Name, Category,
        Latitude, Longitude, RadiusMeters, Priority,
        DescriptionVi, DescriptionEn,
        COALESCE(
            CASE UPPER(@Language)
                WHEN N'VN' THEN DescriptionVi
                WHEN N'EN' THEN DescriptionEn
                WHEN N'JP' THEN DescriptionJp
                WHEN N'KR' THEN DescriptionKr
                WHEN N'CN' THEN DescriptionCn
            END,
            DescriptionEn,
            DescriptionVi,
            N''
        ) AS Description,
        IsActive
    FROM dbo.PointsOfInterest
    WHERE IsActive = 1
    ORDER BY Priority DESC, Id;
END
GO

/* 6.2 — sp_LogNarration */
CREATE PROCEDURE dbo.sp_LogNarration
    @PoiId    INT,
    @Language NVARCHAR(5)
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.NarrationLog (PoiId, Language)
    VALUES (@PoiId, @Language);
END
GO

/* 6.3 — sp_GetPoiDetail: full info 1 POI + breakdown log theo ngôn ngữ */
CREATE PROCEDURE dbo.sp_GetPoiDetail
    @Id INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT * FROM dbo.vw_PoiFull WHERE Id = @Id;

    SELECT Language, COUNT(*) AS PlayCount
    FROM dbo.NarrationLog
    WHERE PoiId = @Id
    GROUP BY Language
    ORDER BY PlayCount DESC;
END
GO

/* 6.4 — sp_GetDashboardStats: summary cho trang chủ web admin */
CREATE PROCEDURE dbo.sp_GetDashboardStats
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        (SELECT COUNT(*) FROM dbo.PointsOfInterest WHERE IsActive = 1) AS ActivePois,
        (SELECT COUNT(*) FROM dbo.PointsOfInterest WHERE IsActive = 0) AS InactivePois,
        (SELECT COUNT(*) FROM dbo.NarrationLog)                        AS TotalPlays,
        (SELECT COUNT(*) FROM dbo.NarrationLog
            WHERE PlayedAt >= CAST(GETDATE() AS DATE))                 AS TodayPlays;

    SELECT Category, COUNT(*) AS Cnt
    FROM dbo.PointsOfInterest
    WHERE IsActive = 1
    GROUP BY Category;

    SELECT TOP 5 * FROM dbo.vw_TopPois;

    SELECT * FROM dbo.vw_NarrationByLanguage;
END
GO

PRINT N'Database VinhKhanhGuide v2 created successfully.';
PRINT N'Next: chạy SeedData.sql để nạp 25 POI mẫu.';
GO
