/* =====================================================================
   VinhKhanhGuide — Seed Data (25 POI)
   ---------------------------------------------------------------------
   - 22 POI gốc từ bảng ảnh (phố Vĩnh Khánh, Q4)
   - 3 POI thêm cho category 'Khac' (cơm tấm, bún bò, chè)
   - Tất cả đều có DescriptionVi + DescriptionEn
   - POI #1 (Ốc Oanh) có đầy đủ 5 ngôn ngữ để test TTS
   - Ngôn ngữ khác NULL -> app fallback về EN theo sp_GetActivePois
   ---------------------------------------------------------------------
   Chạy sau khi đã có DB: USE VinhKhanhGuide; rồi F5
   ===================================================================== */

USE VinhKhanhGuide;
GO

-- Xoá sạch seed cũ (nếu có) để chạy lại được
DELETE FROM dbo.NarrationLog;
DELETE FROM dbo.PointsOfInterest;
DBCC CHECKIDENT ('dbo.PointsOfInterest', RESEED, 0);
DBCC CHECKIDENT ('dbo.NarrationLog', RESEED, 0);
GO

SET NOCOUNT ON;

/* =============== CATEGORY: OC (8 quán ốc) =============== */

INSERT INTO dbo.PointsOfInterest
    (Name, Category, Latitude, Longitude, RadiusMeters, Priority,
     DescriptionVi, DescriptionEn, DescriptionJp, DescriptionKr, DescriptionCn,
     Address, OpeningHours, PriceRange)
VALUES
(N'Ốc Oanh', N'Oc', 10.760719, 106.703297, 30, 10,
 N'Quán ốc lâu đời và nổi tiếng bậc nhất phố Vĩnh Khánh, nổi tiếng với ốc len xào dừa béo ngậy và sò huyết rang me chua ngọt. Mở cửa từ những năm 1990.',
 N'The oldest and most famous snail restaurant on Vinh Khanh street, renowned for its creamy coconut-sauteed sea snails and tangy tamarind blood cockles. Open since the 1990s.',
 N'ヴィンカイン通りで最も古く有名な貝料理店。ココナッツミルクで炒めた貝とタマリンドソースの赤貝が名物。1990年代から営業。',
 N'빈칸 거리에서 가장 오래되고 유명한 조개 요리 식당. 코코넛 우유로 볶은 바다 달팽이와 타마린드 소스 꼬막이 유명.',
 N'永庆街最古老、最有名的螺类餐厅。以椰汁炒海螺和酸甜罗望子血蛤而闻名。自1990年代开业。',
 N'534 Vĩnh Khánh, Phường 8, Quận 4', N'16:00 - 23:30', N'50k - 150k'),

(N'Quán Ốc 662', N'Oc', 10.760836, 106.703505, 30, 6,
 N'Quán ốc bình dân, nổi tiếng với ốc mỡ xào tỏi ớt và các món hải sản tươi sống giá mềm.',
 N'Casual snail eatery famous for garlic-chili stir-fried fat snails and affordable fresh seafood.',
 NULL, NULL, NULL, N'662 Vĩnh Khánh, Q4', N'17:00 - 23:00', N'40k - 120k'),

(N'Ốc Đào 2', N'Oc', 10.761137, 106.704979, 30, 7,
 N'Chi nhánh mới của thương hiệu Ốc Đào huyền thoại, menu đa dạng với hơn 30 loại ốc từ khắp Việt Nam.',
 N'Second branch of the legendary Oc Dao brand, with over 30 types of snails from across Vietnam.',
 NULL, NULL, NULL, N'212 Vĩnh Khánh, Q4', N'15:00 - 24:00', N'60k - 200k'),

(N'Quán Ốc Bụi', N'Oc', 10.760597, 106.704217, 30, 5,
 N'Quán ốc vỉa hè đậm chất Sài Gòn, không gian mộc mạc, món tủ là ốc móng tay xào bơ tỏi.',
 N'Authentic sidewalk snail shack, rustic atmosphere, signature dish is razor clams in garlic butter.',
 NULL, NULL, NULL, NULL, N'17:30 - 23:00', N'40k - 100k'),

(N'Ốc Hoa', N'Oc', 10.760713, 106.704217, 30, 5,
 N'Quán ốc gia đình lâu năm, nổi tiếng với nghêu hấp Thái và ốc bươu nhồi thịt.',
 N'Long-established family-run snail restaurant, known for Thai-style steamed clams and stuffed apple snails.',
 NULL, NULL, NULL, NULL, N'16:30 - 23:00', N'45k - 130k'),

(N'Quán Ốc Sáu Nở', N'Oc', 10.760964, 106.702942, 30, 6,
 N'Quán ốc đông khách nhất đoạn đầu đường Vĩnh Khánh, nổi tiếng với sò điệp nướng mỡ hành.',
 N'The busiest snail spot on the start of Vinh Khanh street, famous for grilled scallops with scallion oil.',
 NULL, NULL, NULL, NULL, N'16:00 - 23:30', N'50k - 150k'),

(N'Quán Ốc Vũ', N'Oc', 10.761403, 106.702705, 30, 4,
 N'Quán nhỏ nhưng chất lượng, ốc tươi nhập hàng ngày từ Cần Giờ.',
 N'Small but quality spot, snails sourced fresh daily from Can Gio.',
 NULL, NULL, NULL, NULL, N'17:00 - 23:00', N'45k - 130k'),

(N'Ốc Phát', N'Oc', 10.761955, 106.702094, 30, 4,
 N'Ốc ngon Quận 4 - Quán có menu dài nhất con đường với hơn 40 món ốc khác nhau.',
 N'District 4 snail specialist - the longest menu on the street with over 40 different snail dishes.',
 NULL, NULL, NULL, NULL, N'16:00 - 24:00', N'50k - 180k');


/* =============== CATEGORY: NUONG (6 quán nướng) =============== */

INSERT INTO dbo.PointsOfInterest
    (Name, Category, Latitude, Longitude, RadiusMeters, Priority,
     DescriptionVi, DescriptionEn,
     Address, OpeningHours, PriceRange)
VALUES
(N'Tiệm Nướng 10 Năm', N'Nuong', 10.760537, 106.703528, 30, 7,
 N'Quán nướng có thâm niên 10 năm, nổi tiếng với sườn cừu nướng mật ong và ba chỉ bò Mỹ.',
 N'Decade-old BBQ joint famous for honey-grilled lamb ribs and American beef brisket.',
 NULL, N'17:00 - 23:00', N'100k - 300k'),

(N'Hàu Nướng A Trung', N'Nuong', 10.760669, 106.703673, 30, 8,
 N'Chuyên hàu tươi sống Nha Trang nướng phô mai, mỡ hành, và sốt Thái đặc biệt.',
 N'Specializing in live Nha Trang oysters grilled with cheese, scallion oil, or special Thai sauce.',
 NULL, N'16:30 - 23:30', N'150k - 400k'),

(N'Lẩu Mẹt Nướng 79k', N'Nuong', 10.760806, 106.704310, 30, 5,
 N'Buffet nướng và lẩu chỉ 79k/người, phù hợp sinh viên và nhóm bạn.',
 N'All-you-can-eat BBQ and hotpot for just 79k VND per person, popular with students and groups.',
 NULL, N'17:00 - 22:30', N'79k (buffet)'),

(N'Trạm Nướng BBQ', N'Nuong', 10.760728, 106.704679, 30, 5,
 N'Không gian hiện đại, thịt nướng kiểu Hàn Quốc với marinate đậm đà.',
 N'Modern space, Korean-style grilled meats with rich marinades.',
 NULL, N'17:30 - 23:00', N'150k - 350k'),

(N'Thèm Nướng Yakiniku', N'Nuong', 10.760778, 106.704739, 30, 6,
 N'Nhà hàng yakiniku chuẩn Nhật, thịt bò Wagyu nhập khẩu và nước chấm tự pha.',
 N'Authentic Japanese yakiniku restaurant with imported Wagyu beef and house-made dipping sauces.',
 NULL, N'18:00 - 23:00', N'250k - 800k'),

(N'Thế Giới Bò - Nướng & Lẩu', N'Nuong', 10.764036, 106.701278, 30, 6,
 N'Chuỗi nhà hàng bò, có đủ kiểu bò nướng từ Hàn, Nhật, đến Việt.',
 N'Beef-focused chain with every style of grilled beef: Korean, Japanese, Vietnamese.',
 NULL, N'11:00 - 23:00', N'200k - 500k');


/* =============== CATEGORY: LAU (4 quán lẩu) =============== */

INSERT INTO dbo.PointsOfInterest
    (Name, Category, Latitude, Longitude, RadiusMeters, Priority,
     DescriptionVi, DescriptionEn,
     Address, OpeningHours, PriceRange)
VALUES
(N'Lẩu Bò Kỳ Kim', N'Lau', 10.761460, 106.702608, 30, 7,
 N'Quán lẩu bò gia truyền, nước dùng ninh xương 12 tiếng, gân bò mềm rục và bắp hoa giòn sần sật.',
 N'Family-tradition beef hotpot with bone broth simmered 12 hours, featuring tender beef tendon and crunchy shank.',
 NULL, N'16:00 - 23:00', N'180k - 400k'),

(N'Lẩu Mẹt Nướng 79k (Lẩu)', N'Lau', 10.760806, 106.704310, 30, 5,
 N'Combo lẩu mẹt + nướng 79k bao gồm rau, thịt, hải sản không giới hạn.',
 N'Hotpot and BBQ combo for 79k with unlimited veggies, meats, and seafood.',
 NULL, N'17:00 - 22:30', N'79k (buffet)'),

(N'Thế Giới Bò - Lẩu', N'Lau', 10.764036, 106.701278, 30, 5,
 N'Phiên bản lẩu của Thế Giới Bò, nổi tiếng với lẩu bò Tây Tạng và lẩu đuôi bò.',
 N'Hotpot version of The Gioi Bo, famous for Tibetan beef hotpot and oxtail hotpot.',
 NULL, N'11:00 - 23:00', N'200k - 500k'),

(N'Lẩu Gà Lá É Con Gà Trống', N'Lau', 10.760856, 106.706722, 30, 6,
 N'Đặc sản Phú Yên, lẩu gà ác hầm lá é có vị cay the đặc trưng, ăn kèm bún tươi.',
 N'Phu Yen specialty: silkie chicken hotpot with basil leaves featuring a distinctive spicy tang, served with fresh vermicelli.',
 NULL, N'16:00 - 23:00', N'250k - 500k');


/* =============== CATEGORY: CAFE (4 quán cà phê) =============== */

INSERT INTO dbo.PointsOfInterest
    (Name, Category, Latitude, Longitude, RadiusMeters, Priority,
     DescriptionVi, DescriptionEn,
     Address, OpeningHours, PriceRange)
VALUES
(N'Tiệm Cà Phê Lucky', N'CaPhe', 10.760451, 106.707005, 30, 4,
 N'Quán cà phê vintage với đồ uống signature là cà phê trứng và matcha latte.',
 N'Vintage-style coffee shop known for signature egg coffee and matcha latte.',
 NULL, N'07:00 - 22:00', N'35k - 75k'),

(N'Xù Phê', N'CaPhe', 10.761201, 106.706101, 30, 4,
 N'Quán cà phê take-away giá học sinh sinh viên, đồ uống đá xay được yêu thích nhất.',
 N'Student-friendly take-away coffee shop, most popular for blended ice drinks.',
 NULL, N'07:30 - 22:30', N'20k - 50k'),

(N'Link Coffee & Tea', N'CaPhe', 10.760846, 106.704983, 30, 4,
 N'Tiệm cà phê và trà sữa kết hợp, không gian thoáng mát, wifi khỏe, hợp dân văn phòng.',
 N'Combined coffee and bubble tea shop with airy space, strong wifi, popular with office workers.',
 NULL, N'07:00 - 23:00', N'30k - 70k'),

(N'Quán Nước SINZIEN', N'CaPhe', 10.761756, 106.702283, 30, 3,
 N'Quán nước nhỏ nhưng đáng yêu, menu sinh tố và nước ép trái cây tươi.',
 N'Small but charming drink shop with a menu of smoothies and fresh fruit juices.',
 NULL, N'07:00 - 22:00', N'25k - 55k');


/* =============== CATEGORY: KHAC (3 quán món khác) =============== */

INSERT INTO dbo.PointsOfInterest
    (Name, Category, Latitude, Longitude, RadiusMeters, Priority,
     DescriptionVi, DescriptionEn,
     Address, OpeningHours, PriceRange)
VALUES
(N'Cơm Tấm Ba Ghiền', N'Khac', 10.761000, 106.703800, 30, 6,
 N'Quán cơm tấm nổi tiếng nhất khu Vĩnh Khánh, sườn nướng to gấp đôi bình thường, từng lọt top Michelin Bib Gourmand.',
 N'The most famous broken rice spot in Vinh Khanh, with grilled pork chops double the usual size. Michelin Bib Gourmand listed.',
 NULL, N'06:00 - 14:00 & 17:00 - 22:00', N'50k - 120k'),

(N'Bún Bò Huế Đông Ba', N'Khac', 10.761500, 106.704500, 30, 5,
 N'Quán bún bò Huế chuẩn vị cố đô, nước lèo đậm đà sả và ruốc Huế.',
 N'Authentic Hue-style beef noodle soup with rich broth of lemongrass and Hue shrimp paste.',
 NULL, N'06:00 - 13:00 & 17:00 - 21:00', N'45k - 80k'),

(N'Chè Mâm Bùi Hữu Nghĩa', N'Khac', 10.760900, 106.705800, 30, 3,
 N'Chè mâm Huế với hơn 20 loại chè khác nhau trên một mâm, tráng miệng hoàn hảo sau buffet ốc.',
 N'Hue-style dessert platter with over 20 different sweet soups in one tray — the perfect finale after a snail feast.',
 NULL, N'10:00 - 23:00', N'40k - 80k');

GO

PRINT N'✅ Seed 25 POI hoàn tất.';
SELECT Category, COUNT(*) AS SoLuong
FROM dbo.PointsOfInterest
GROUP BY Category
ORDER BY Category;
GO
