using System;
using System.Linq;
using System.Windows.Forms;
using VinhKhanhGuide.Models;
using Windows.Media.Core;
using Windows.Media.Playback;
using Windows.Media.SpeechSynthesis;

namespace VinhKhanhGuide.Services
{
    /// <summary>
    /// TTS realtime dùng Windows.Media.SpeechSynthesis (WinRT) — đọc được
    /// các OneCore voices như Microsoft An (vi-VN). System.Speech (SAPI 5)
    /// KHÔNG thấy được những voice này nên không dùng nữa.
    /// </summary>
    public class NarrationService : IDisposable
    {
        private readonly SpeechSynthesizer _synth;
        private readonly MediaPlayer _player;
        private VoiceInformation _currentVoice;

        public NarrationLanguage Language { get; private set; } = NarrationLanguage.VN;
        public bool IsSpeaking { get; private set; }

        public event EventHandler<string> SpeakingStarted;
        public event EventHandler SpeakingCompleted;

        public NarrationService()
        {
            _synth = new SpeechSynthesizer();
            _player = new MediaPlayer();

            _player.MediaEnded += (s, e) =>
            {
                IsSpeaking = false;
                SpeakingCompleted?.Invoke(this, EventArgs.Empty);
            };
            _player.MediaFailed += (s, e) =>
            {
                IsSpeaking = false;
                SpeakingCompleted?.Invoke(this, EventArgs.Empty);
                System.Diagnostics.Debug.WriteLine("[Narration] MediaFailed: " + e.ErrorMessage);
            };

            PrintInstalledVoices();
            SetLanguage(NarrationLanguage.VN);
        }

        /// <summary>Debug: in tất cả voice WinRT thấy được ra Output window.</summary>
        public void PrintInstalledVoices()
        {
            System.Diagnostics.Debug.WriteLine("=== WinRT Voices (cái app dùng) ===");
            foreach (var v in SpeechSynthesizer.AllVoices)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"  {v.Language,-8} | {v.Gender,-6} | {v.DisplayName}");
            }
            System.Diagnostics.Debug.WriteLine($"  Default: {SpeechSynthesizer.DefaultVoice?.DisplayName}");
        }

        public bool SetLanguage(NarrationLanguage lang)
        {
            Language = lang;
            string wantTag = lang.ToCulture().Name;  // vi-VN, ja-JP, ...

            var match = SpeechSynthesizer.AllVoices.FirstOrDefault(v =>
                            v.Language.Equals(wantTag, StringComparison.OrdinalIgnoreCase))
                     ?? SpeechSynthesizer.AllVoices.FirstOrDefault(v =>
                            v.Language.StartsWith(wantTag.Substring(0, 2),
                                                  StringComparison.OrdinalIgnoreCase));

            if (match == null)
            {
                MessageBox.Show(
                    $"Windows chưa cài giọng đọc cho {lang.DisplayName()} ({wantTag}).\n\n" +
                    "Cách cài:\n" +
                    "  1. Settings → Time & Language → Speech\n" +
                    "  2. Manage voices → Add voices\n" +
                    "  3. Chọn ngôn ngữ → Install\n" +
                    "  4. RESTART Windows\n" +
                    "  5. Chạy lại app\n\n" +
                    "App sẽ KHÔNG đọc bằng giọng khác để tránh sai phát âm.",
                    "Thiếu Voice Pack",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                _currentVoice = null;
                return false;
            }

            _currentVoice = match;
            _synth.Voice = match;
            System.Diagnostics.Debug.WriteLine($"[Narration] Selected voice: {match.DisplayName} ({match.Language})");
            return true;
        }

        public async void Speak(PointOfInterest poi)
        {
            if (poi == null) return;
            if (_currentVoice == null) return; // đã cảnh báo trong SetLanguage

            Stop();

            string desc = Language == NarrationLanguage.VN
                ? poi.GetDescription("VN")
                : poi.GetDescription("EN");
            string text = $"{poi.Name}. {desc}";

            try
            {
                IsSpeaking = true;
                SpeakingStarted?.Invoke(this, poi.Name);

                var stream = await _synth.SynthesizeTextToStreamAsync(text);
                _player.Source = MediaSource.CreateFromStream(stream, stream.ContentType);
                _player.Play();
            }
            catch (Exception ex)
            {
                IsSpeaking = false;
                SpeakingCompleted?.Invoke(this, EventArgs.Empty);
                System.Diagnostics.Debug.WriteLine("[Narration] " + ex.Message);
            }
        }

        public void Stop()
        {
            try
            {
                _player.Pause();
                _player.Source = null;
            }
            catch { }
            IsSpeaking = false;
        }

        public void Dispose()
        {
            Stop();
            _player.Dispose();
        }
    }
}